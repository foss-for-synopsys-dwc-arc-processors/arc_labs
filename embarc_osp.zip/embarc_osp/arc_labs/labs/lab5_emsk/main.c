/* ------------------------------------------
 * Copyright (c) 2018, Synopsys, Inc. All rights reserved.

 * Redistribution and use in source and binary forms, with or without modification,
 * are permitted provided that the following conditions are met:

 * 1) Redistributions of source code must retain the above copyright notice, this
 * list of conditions and the following disclaimer.

 * 2) Redistributions in binary form must reproduce the above copyright notice,
 * this list of conditions and the following disclaimer in the documentation and/or
 * other materials provided with the distribution.

 * 3) Neither the name of the Synopsys, Inc., nor the names of its contributors may
 * be used to endorse or promote products derived from this software without
 * specific prior written permission.

 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS" AND
 * ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED
 * WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
 * DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE FOR
 * ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
 * (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;
 * LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON
 * ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
 * (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS
 * SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 *
--------------------------------------------- */

/* embARC HAL */
#include "embARC.h"
#include "embARC_debug.h"

#define LED_MASK		BOARD_LED_MASK
#define BTN_MASK		BOARD_BTN_MASK
#define SWT_MASk		BOARD_SWT_MASK


/**
 * \brief	Test hardware board without any peripheral
 */
int main(void)
{
	uint16_t led_val = 0x0000;
	uint16_t btn_val = 0x0000;
	uint16_t swt_val = 0x0000;
	uint16_t pri_cnt = 0x0000;

	while (1)
	{
		led_val = 0x0000;
		btn_val = button_read(BOARD_BTN_MASK);
		swt_val = switch_read(BOARD_SWT_MASK);

		led_val = (btn_val<<4) + swt_val;

		led_write(led_val, BOARD_LED_MASK);

		board_delay_ms(10, 1);

		if(pri_cnt >= 100)
		{
			pri_cnt = 0;
			EMBARC_PRINTF("\r\nThe Button is 0x%x\r\n",btn_val);
			EMBARC_PRINTF("The Switch is 0x%x\r\n",swt_val);
		}
		else
		{
			pri_cnt ++;
		}
	}

	return E_SYS;
}

/** @} */