.. _labs:

Hands-on labs
#################

.. toctree::
    :maxdepth: 2

    level1.rst
    level2.rst
    level3.rst