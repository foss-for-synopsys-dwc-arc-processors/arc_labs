.. _level1_labs:

Basic labs
############

.. toctree::
    :maxdepth: 1
    :glob:

    level1/lab1
    level1/lab2
    level1/lab5
    level1/lab3
    level1/lab4
    level1/lab6