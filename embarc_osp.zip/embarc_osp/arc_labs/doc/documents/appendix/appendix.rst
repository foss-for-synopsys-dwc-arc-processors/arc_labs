.. _appendix:

Appendix
========

Reference
#########

#. `Online docs <http://embarc.org/embarc_osp/>`__
#. `ARC EM Starter Kit Webpage <https://www.synopsys.com/dw/ipdir.php?ds=arc_em_starter_kit>`_
#. `ARC IoT Development Kit Webpage <https://www.synopsys.com/dw/ipdir.php?ds=arc_iot_development_kit>`_
#. `Github Repository of embARC Open Software Platform (OSP) <https://github.com/foss-for-synopsys-dwc-arc-processors/embarc_osp>`__