.. _board_axs:

ARC Software Development Platform
=================================

The ARC Software Development Platform is a powerful, high-speed development
platform, enabling real-time software development and validation, code
porting, software debugging, and system analysis. Readily available DesignWare
IP has been used to build the ARC Software Development Platform, which is thus
well-suited for SoC prototyping including ARC CPUs.
