.. _pull_request_guidelines:


Pull Request Template
=====================


* Summarize the main changes or features of your pull request.
* Describe the development status of your pull request.
* List all the related issues of your pull request.

ToDos
-----


* [] Todo list 1
* [] Todo list 2

User Manual
-----------

Describe about how to test or reproduce the new features or bugs fixed of your pull request.
