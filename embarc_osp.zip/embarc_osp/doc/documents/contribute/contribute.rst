.. _contribute:

Contribute to embARC OSP
========================

.. toctree::
    :maxdepth: 1

    CONTRIBUTING.rst
    CODE_OF_CONDUCT.rst
    ISSUE_TEMPLATE.rst
    PULL_REQUEST_TEMPLATE.rst